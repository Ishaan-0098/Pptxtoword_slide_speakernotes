# flake8: noqa

from .azure_tts import azure_text_to_speech
from .google_tts import google_text_to_speech
